package modelo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EstadoTestGestionarCola {
	Estado estado;

	@BeforeEach
	void beforeEach() {
		estado = new Estado();
		for (int i = 0; i < 8; i++) {

			estado.getSectorParados().offerLast(new Adulto(20, 70, 100, 1000));
			estado.getSectorTrabajadores().offerLast(new Adulto(20, 80, 100, 1000));

		}
	}

	@Test
	void testGestionarEmpleosContratar() {

		estado.gestionarEmpleos(1200);
		assertEquals(4, estado.getParados().size());
		assertEquals(12, estado.getTrabajadores().size());
	}
	@Test
	void testGestionarEmpleosDespedir(){
		estado.gestionarEmpleos(600);
		assertEquals(10,estado.getParados().size());
		assertEquals(6, estado.getTrabajadores().size());
		}
}
